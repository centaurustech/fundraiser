# Generating Documentation

Generating documentation is easy.  Simply cd into the documentation/dox folder and type doxgen.php.  Current HTML documentation will be generated in documentation/html

