<div class="page-header">
	<h1>PHP-Payments supports x gateways and x methods</h1>
</div>
	<div class="row-fluid">
		<div class="span8">
			
		</div>