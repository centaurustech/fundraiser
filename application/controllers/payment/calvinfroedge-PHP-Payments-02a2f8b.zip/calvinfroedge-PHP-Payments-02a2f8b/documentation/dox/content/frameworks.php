<div class="page-header">
	<h1>PHP-Payments is coming to a framework near you!</h1>
</div>
	<div class="row-fluid">
		<div class="span8">
			<div class="row-fluid">
				<!--<h2>CodeIgniter</h2>
				<p>CodeIgniter is where it all began!  The original CodeIgniter spark supported 8 gateways and was installed more than 500 times before being converted to PHP-Payments.  The spark now sits on top of the PHP-Payments codebase, and you can <a href="http://getsparks.org/packages/codeigniter-payments/versions/HEAD/show" target="_blank">install via sparks.</a></p>

				<h2>FuelPHP</h2>
				<p>Download the <a href="https://github.com/calvinfroedge/FuelPay" target="_blank">FuelPHP Payments package (FuelPay) from Github</a></p>-->
				<h2>Coming Soon!</h2>
			</div>
		</div>