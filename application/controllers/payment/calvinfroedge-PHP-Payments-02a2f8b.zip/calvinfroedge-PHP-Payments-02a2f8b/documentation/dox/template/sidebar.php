	<div class="span4">
		<h2>Support PHP-Payments</h2>
		<p>This stuff takes a lot of hard work.  To date, we've logged hundreds of hours on this project, and sadly free code doesn't pay bills.</p>
		<a href="https://flattr.com/submit/auto?user_id=calvinfroedge&url=http://github.com/calvinfroedge/codeigniter-payments&title=Codeigniter%20Payments&language=en_GB&tags=github&category=software" class="btn btn-large btn-primary">Make a Donation</a>
		<a href="/add_drivers.html" class="btn btn-large">Contribute Code</a>
	</div>
</div>
