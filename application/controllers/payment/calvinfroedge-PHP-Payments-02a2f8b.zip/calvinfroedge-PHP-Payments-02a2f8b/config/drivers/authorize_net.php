<?php

$config['api_username'] = "25xTC7vJp";
$config['api_password'] = "3zF64K5BA9a3y6rG";
//Note: you can sign into the test interface at test.authorize.net
$config['email_customer'] = TRUE;

return $config;
