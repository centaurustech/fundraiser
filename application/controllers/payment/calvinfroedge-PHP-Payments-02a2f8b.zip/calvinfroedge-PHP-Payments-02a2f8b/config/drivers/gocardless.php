<?php

$config = array(
	'app_identifier' => 'mCeiwZDpJ6Qt_ktvePBvFQPCqoVTPE6nCbaG17IWl6UPqxZtda967ezzyXjI_wwm',
	'app_secret' => 'nAdkW9Geud8lOXguS_qUYNM2C96J5DFRA0nmbpKFheJUzxj85SQI2qm1gyrE1aFf',
	'access_token' => 'HckEz6jLMRxSfWSHqxHrRMJlQF3VGFQo1UGts46X1veyBIejzZ3emeb0sLYA7LqY',
	'id' => '01FCVJW4YC'
);

return $config;