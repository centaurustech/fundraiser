<?php
$config['api_cid'] = "87654321";

return $config;