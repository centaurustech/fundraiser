<?php

$config['api_username'] = "iambrs_1298074268_biz_api1.gmail.com";
$config['api_password'] = "1298074286";
$config['api_signature'] = "Awe05O9DgD-XyAL3-HsFoqNs..1VAOncRYkwEN.LCh-94svEO5c0i0Ar ";

return $config;