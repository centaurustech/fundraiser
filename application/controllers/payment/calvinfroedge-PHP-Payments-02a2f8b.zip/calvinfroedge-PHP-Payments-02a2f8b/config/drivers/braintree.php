<?php

$config['merchantId'] = '232324234';
$config['publicKey'] = 'asdfasdfa232f';
$config['privateKey'] = 'dafsdf23';

return $config;
