<?php

$config = array(
	'merchant_id' => 'test',
	'merchant_key' => 'test',
	'request_buyer_phone' => true,
	'button_size' => 'SMALL'
);

return $config;
