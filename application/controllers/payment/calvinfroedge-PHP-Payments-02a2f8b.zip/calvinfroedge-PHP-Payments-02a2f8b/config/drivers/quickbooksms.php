<?php

$config['api_application_login'] = "cfpayments.codeigniter.local";
$config['api_connection_ticket'] = "TGT-172-3nhcl7svhgXazfMDkaC_QQ";
$config['api_endpoint_test'] = "https://merchantaccount.ptc.quickbooks.com/j/AppGateway";
$config['api_endpoint_production'] = "https://merchantaccount.quickbooks.com/j/AppGateway";
$config['api_qbxml'] = 'qbmsxml version="4.5"';

return $config;