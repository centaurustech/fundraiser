<?php

$config['api_key'] = 'hbsNLQGp21CVK4Cs1dOLXZQ38BbB37rR';

return $config;
