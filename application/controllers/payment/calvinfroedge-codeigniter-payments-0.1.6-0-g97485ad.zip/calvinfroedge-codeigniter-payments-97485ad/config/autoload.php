<?php

$autoload['libraries'] = array('payments');
